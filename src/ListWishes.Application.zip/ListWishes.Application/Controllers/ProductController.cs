﻿using ListWishes.Domain.Entities;
using ListWishes.Service.Services;
using ListWishes.Service.Validators;
using Microsoft.AspNetCore.Mvc;
using System;

namespace ListWishes.Application.Controllers
{
    [Produces("application/json")]
    [Route("api/Produto")]
    public class ProductController : Controller
    {
        private BaseService<Product> service = new BaseService<Product>();

        public IActionResult Post([FromBody] Product item)
        {
            try
            {
                service.Post<ProductValidator>(item);

                return new ObjectResult(item.Id);
            }
            catch(ArgumentNullException ex)
            {
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        public IActionResult Put([FromBody] Product item)
        {
            try
            {
                service.Put<ProductValidator>(item);

                return new ObjectResult(item);
            }
            catch(ArgumentNullException ex)
            {
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        public IActionResult Delete(int id)
        {
            try
            {
                service.Delete(id);

                return new NoContentResult();
            }
            catch(ArgumentException ex)
            {
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        public IActionResult Get()
        {
            try
            {
                return new ObjectResult(service.Get());
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        public IActionResult Get(int id)
        {
            try
            {
                return new ObjectResult(service.Get(id));
            }
            catch(ArgumentException ex)
            {
                return NotFound(ex);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}